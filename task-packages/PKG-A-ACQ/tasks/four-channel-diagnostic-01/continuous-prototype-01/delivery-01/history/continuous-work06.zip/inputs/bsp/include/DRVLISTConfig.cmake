set(DRIVER_LIST axidma;common;coresightps_dcc;devcfg;dmaps;gpio;qspips;scugic;scutimer;scuwdt;uartps;xadcps)
