# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "FIFO_LOG2" -parent ${Page_0}
  ipgui::add_param $IPINST -name "SAMPLES_PER_PACKET" -parent ${Page_0}
  ipgui::add_param $IPINST -name "TOTAL_SAMPLES" -parent ${Page_0}
  ipgui::add_param $IPINST -name "WARMUP_SAMPLES" -parent ${Page_0}


}

proc update_PARAM_VALUE.FIFO_LOG2 { PARAM_VALUE.FIFO_LOG2 } {
	# Procedure called to update FIFO_LOG2 when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.FIFO_LOG2 { PARAM_VALUE.FIFO_LOG2 } {
	# Procedure called to validate FIFO_LOG2
	return true
}

proc update_PARAM_VALUE.SAMPLES_PER_PACKET { PARAM_VALUE.SAMPLES_PER_PACKET } {
	# Procedure called to update SAMPLES_PER_PACKET when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SAMPLES_PER_PACKET { PARAM_VALUE.SAMPLES_PER_PACKET } {
	# Procedure called to validate SAMPLES_PER_PACKET
	return true
}

proc update_PARAM_VALUE.TOTAL_SAMPLES { PARAM_VALUE.TOTAL_SAMPLES } {
	# Procedure called to update TOTAL_SAMPLES when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.TOTAL_SAMPLES { PARAM_VALUE.TOTAL_SAMPLES } {
	# Procedure called to validate TOTAL_SAMPLES
	return true
}

proc update_PARAM_VALUE.WARMUP_SAMPLES { PARAM_VALUE.WARMUP_SAMPLES } {
	# Procedure called to update WARMUP_SAMPLES when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.WARMUP_SAMPLES { PARAM_VALUE.WARMUP_SAMPLES } {
	# Procedure called to validate WARMUP_SAMPLES
	return true
}


proc update_MODELPARAM_VALUE.WARMUP_SAMPLES { MODELPARAM_VALUE.WARMUP_SAMPLES PARAM_VALUE.WARMUP_SAMPLES } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.WARMUP_SAMPLES}] ${MODELPARAM_VALUE.WARMUP_SAMPLES}
}

proc update_MODELPARAM_VALUE.TOTAL_SAMPLES { MODELPARAM_VALUE.TOTAL_SAMPLES PARAM_VALUE.TOTAL_SAMPLES } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.TOTAL_SAMPLES}] ${MODELPARAM_VALUE.TOTAL_SAMPLES}
}

proc update_MODELPARAM_VALUE.SAMPLES_PER_PACKET { MODELPARAM_VALUE.SAMPLES_PER_PACKET PARAM_VALUE.SAMPLES_PER_PACKET } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SAMPLES_PER_PACKET}] ${MODELPARAM_VALUE.SAMPLES_PER_PACKET}
}

proc update_MODELPARAM_VALUE.FIFO_LOG2 { MODELPARAM_VALUE.FIFO_LOG2 PARAM_VALUE.FIFO_LOG2 } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.FIFO_LOG2}] ${MODELPARAM_VALUE.FIFO_LOG2}
}

