xsim {tb_production_sim} -autoloadwcfg -runall
