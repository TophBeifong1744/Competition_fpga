xsim {tb_frontend_sim} -autoloadwcfg -runall
