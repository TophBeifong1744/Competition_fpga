xsim {tb_continuous_sim} -autoloadwcfg -runall
