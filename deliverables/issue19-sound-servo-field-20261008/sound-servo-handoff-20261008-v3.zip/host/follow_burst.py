"""One-board finite-burst acoustic-to-servo diagnostic; never replay controls."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import secrets
import struct
import sys
import time
import zlib
import numpy as np

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "models/python"))
from soundsight_h3_portable.bindings import Bindings
from soundsight_h3_portable.chain import ActivityState, run_numeric_frame

HEADER = struct.Struct("<4sBBHIIHBBI")
TTL_SECONDS = 10.0

def command(op, nonce, window=0, angle=0):
    body = struct.pack("<2sBBIIH", b"SC", op, 0, nonce, window, angle)
    checksum = 0
    for byte in body:
        checksum ^= byte
    return body + bytes((checksum, 10))

def map_target(angle_q8, zero, polarity):
    # Source azimuth is wrapped to [-180,180), mechanical target is not wrapped.
    signed = ((angle_q8 / 256.0 + 180.0) % 360.0) - 180.0
    value = int(round(zero + polarity * signed))
    if not 0 <= value <= 360:
        raise ValueError(f"OUTSIDE_DRIVER_RANGE: {value}")
    return value

def decode_pcm(payload):
    raw = np.frombuffer(payload, dtype=np.uint8).reshape(2048, 4, 3).astype(np.int32)
    words = raw[:, :, 0] | (raw[:, :, 1] << 8) | (raw[:, :, 2] << 16)
    return ((words ^ 0x800000) - 0x800000).astype(np.int32)

def read_exact(port, count, deadline):
    chunks = bytearray()
    while len(chunks) < count:
        if time.monotonic() >= deadline:
            raise TimeoutError("SERIAL_PACKET_TIMEOUT")
        part = port.read(count - len(chunks))
        chunks.extend(part)
    return bytes(chunks)

def receive(port, nonce, window, wanted, deadline):
    header = read_exact(port, HEADER.size, deadline)
    magic, kind, status, reserved, seen_nonce, seen_window, samples, channels, width, fs = HEADER.unpack(header)
    if (magic != b"SSB1" or kind != wanted or reserved != 0 or seen_nonce != nonce
            or seen_window != window or channels != 4 or width != 3 or fs != 48000
            or samples != (2048 if kind == 1 else 0)):
        raise ValueError("PACKET_IDENTITY_OR_RESET_MISMATCH")
    payload = read_exact(port, samples * channels * width, deadline)
    check = struct.unpack("<I", read_exact(port, 4, deadline))[0]
    if zlib.crc32(header + payload) != check:
        raise ValueError("PACKET_CRC_FAIL")
    if status:
        raise ValueError(f"FIRMWARE_REJECT_OR_CLIP: {status}")
    return payload, header

def numeric(pcm, window, activity, bindings):
    stages = []
    for index in range(3):
        identity = dict(boot="HOST_DIAGNOSTIC", session="LIVE_SERIAL", interval=str(window),
                        frame=index, generation=window, last_id=index * 512 + 1023)
        stage = run_numeric_frame(pcm[index*512:index*512+1024], identity, activity, bindings)
        stages.append(stage)
    bindings.verify_post()
    return stages

def jsonable(value):
    if isinstance(value, dict): return {str(k): jsonable(v) for k,v in value.items()}
    if isinstance(value, (list, tuple)): return [jsonable(v) for v in value]
    if isinstance(value, np.ndarray): return value.tolist()
    if isinstance(value, np.generic): return value.item()
    return value

def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", required=True, help="COM3; close SSCOM and Vitis serial first")
    parser.add_argument("--zero", required=True, type=float, help="Installed mechanical target for source algorithm0degrees")
    parser.add_argument("--polarity", required=True, type=int, choices=(-1,1))
    parser.add_argument("--confirm-candidate-square", action="store_true", required=True,
                        help="Explicitly accept unmeasured40mm square research geometry")
    parser.add_argument("--channel-order", required=True, help="Permutation of physical channels for model0,1,2,3; e.g.0,1,2,3")
    parser.add_argument("--auto", action="store_true",
                        help="After background, start bounded repeated fresh captures with one Enter")
    parser.add_argument("--cycles", type=int, default=4, choices=range(1,13),
                        help="Number of fresh captures, 1..12 (default: 4)")
    parser.add_argument("--out", type=Path, required=True, help="New evidence directory")
    args = parser.parse_args(argv)
    order = [int(v) for v in args.channel_order.split(",")]
    if sorted(order)!=[0,1,2,3] or not 0 <= args.zero <= 360:
        parser.error("Installedzero/orderinvalid; driverangle0..360")
    if args.out.exists(): parser.error("OUTPUT_EXISTS")
    bindings = Bindings(REPO)
    import serial  # pyserial required only when operating physical COM port
    args.out.mkdir(parents=True)
    log = (args.out / "events.jsonl").open("x",encoding="utf-8")
    def event(kind, **values):
        row=dict(event=kind,monotonic_seconds=time.monotonic(),**values)
        log.write(json.dumps(jsonable(row),ensure_ascii=False)+"\n");log.flush()
        if kind == "target_accepted":
            print(f"{kind} 声源方位={values['source_deg']:.2f}° 舵机目标={values['target']}°", flush=True)
        else:
            print(kind, values.get("target",values.get("reason","")),flush=True)
    nonce=secrets.randbelow(0xffffffff)+1
    port=serial.Serial(args.port,115200,timeout=0.1,write_timeout=1)
    try:
        event("session",nonce=nonce,arguments=vars(args)|{"out":str(args.out)},
              bindings=bindings.identity,claim="FINITE_BURST_DIAGNOSTIC",ttl=TTL_SECONDS)
        port.reset_input_buffer()
        port.write(command(4,nonce));port.flush()
        receive(port,nonce,0,2,time.monotonic()+2)
        port.write(command(1,nonce));port.flush()
        receive(port,nonce,0,2,time.monotonic()+2)
        input("保持安静背景，按回车采一段背景（不移动舵机）：")
        port.write(command(2,nonce,1));port.flush()
        background,header=receive(port,nonce,1,1,time.monotonic()+4)
        (args.out/"background.raw").write_bytes(background)
        background_sha=hashlib.sha256(background).hexdigest()
        pcm=decode_pcm(background)[:,order]
        blank=ActivityState(dict(noise_power_u64=[0]*4,band_rms_floor_codes=1))
        rows=numeric(pcm,1,blank,bindings)
        if any(row["detail"]["numeric_invalid"] for row in rows):
            raise ValueError("BACKGROUND_NUMERIC_INVALID")
        noise=[max(1,max(int(row["arrays"]["gate_band_power_u64"][ch]) for row in rows)) for ch in range(4)]
        event("background",sha256=background_sha,noise_power_u64=noise,
              numeric_details=[r["detail"] for r in rows],header_hex=header.hex())
        port.write(command(4,nonce,1));port.flush()
        receive(port,nonce,1,2,time.monotonic()+2)
        if args.auto:
            input("声源开始持续发声后按一次回车；随后自动逐轮采集，按 Ctrl+C 结束：")
        for cycle in range(args.cycles):
            if args.auto:
                print(f"自动采集 {cycle+1}/{args.cycles}；本轮采集时保持声源位置稳定", flush=True)
            else:
                input("固定声源持续发声；位置不要在采集/计算时改变。按回车开始本轮：")
            # This explicit user edge starts a new unpredictable session. The
            # previous firmware TTL may have expired while positioning sound.
            nonce=secrets.randbelow(0xffffffff)+1
            port.write(command(1,nonce));port.flush()
            receive(port,nonce,0,2,time.monotonic()+2)
            window=1
            requested=time.monotonic()
            port.write(command(2,nonce,window));port.flush()
            payload,header=receive(port,nonce,window,1,requested+4)
            (args.out/f"capture_{cycle+1:02d}.raw").write_bytes(payload)
            received=time.monotonic()
            # Capture completion precedes ~2.14s dump: measuring from request
            # is conservatively stricter than firmware completion-based expiry.
            expiry=requested+TTL_SECONDS
            activity=ActivityState(dict(noise_power_u64=noise,band_rms_floor_codes=1))
            rows=numeric(decode_pcm(payload)[:,order],window,activity,bindings)
            event("numeric",cycle=cycle+1,nonce=nonce,window=window,requested=requested,received=received,
                  expiry=expiry,sha256=hashlib.sha256(payload).hexdigest(),
                  header_hex=header.hex(),details=[r["detail"] for r in rows])
            last=rows[-1]
            if (any(row["detail"]["numeric_invalid"] for row in rows)
                or not last["detail"]["gate_state"]["active"] or last["candidate_angle_q8"] is None):
                event("no_motion",window=window,reason="INVALID_OR_INACTIVE")
                port.write(command(4,nonce,window));port.flush()
                receive(port,nonce,window,2,time.monotonic()+2)
                continue
            try:
                target=map_target(last["candidate_angle_q8"],args.zero,args.polarity)
            except ValueError as exc:
                event("no_motion",window=window,reason=str(exc))
                port.write(command(4,nonce,window));port.flush()
                receive(port,nonce,window,2,time.monotonic()+2)
                continue
            if time.monotonic()>=expiry-0.25:
                raise TimeoutError("HOST_REAL_PROCESS_EXPIRED_NO_MOTION")
            port.write(command(3,nonce,window,target));port.flush()
            receive(port,nonce,window,2,min(expiry,time.monotonic()+2))
            event("target_accepted",window=window,target=target,
                  source_deg=last["candidate_angle_q8"]/256.0,
                  mechanical_arrival="USER_OBSERVATION_REQUIRED")
            port.write(command(4,nonce,window));port.flush()
            receive(port,nonce,window,2,time.monotonic()+2)
    finally:
        # BURST-FINAL-01: successful host write is not firmware confirmation.
        original_error = sys.exc_info()[1]
        cleanup_errors = []
        def cleanup_event(kind, **values):
            try: event(kind, **values)
            except BaseException as exc: cleanup_errors.append(exc)
        try:
            cleanup_event("stop_attempt",confirmation="NOT_RECEIVED")
            try:
                stop_bytes = command(4,nonce)
                written = port.write(stop_bytes)
                if written != len(stop_bytes):
                    raise IOError(f"STOP_SHORT_WRITE: {written}/{len(stop_bytes)}")
                port.flush()
            except BaseException as exc:
                cleanup_errors.append(exc)
                cleanup_event("stop_failed",reason=str(exc),confirmation="NOT_RECEIVED")
            else:
                cleanup_event("stop_sent",confirmation="NOT_RECEIVED",
                              meaning="HOLD_TARGET_PWM_NOT_BRAKE")
        finally:
            try:
                port.close()
            except BaseException as exc:
                cleanup_errors.append(exc)
                cleanup_event("serial_close_failed",reason=str(exc))
            finally:
                try: log.close()
                except BaseException as exc: cleanup_errors.append(exc)
        if original_error is None and cleanup_errors:
            raise cleanup_errors[0]

if __name__=="__main__":
    main()
