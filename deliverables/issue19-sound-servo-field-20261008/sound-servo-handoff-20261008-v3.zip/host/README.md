# 单板四麦 → 电脑算法 → 水平舵机，有限分段诊断

这是新接合的独立候选，原生编译/官方库展开及修复后的有界诊断已完成；最新复核结论见 [当前操作入口](../../docs/C-sound-to-servo-minimal-operation.md) 与 `codex_out/i19-sound-servo-burst-20261007/verification/HANDOFF.md`。综合实现、时序和用户板测仍待执行。不是连续48kHz实时跟踪，不是阶段通过。
一个 bit 同时采四麦、接收目标、产生水平/垂直 PWM；无需PS/Vitis。P5必须为PL（断电后选3–5、4–6），Type-C经CH340；运行Python前关闭SSCOM/Vitis串口。

## Vivado源列表

本次用户指定目标 `xc7z020clg400-1`，Vivado2025.2，顶层 `sound_servo_burst_top`。
添加以下Design Sources，保持原路径、不要改已有源：

- `project/rtl/servo/sound_servo_burst_top.sv`
- `project/rtl/servo/sound_servo_clock.sv`
- `project/rtl/servo/sound_servo_capture.sv`
- `project/rtl/servo/sound_servo_burst_core.sv`
- `project/rtl/servo/servo_uart_rx.sv`
- `project/rtl/servo/servo_uart_tx.sv`
- `project/rtl/servo/motor_drive.v`
- `task-packages/PKG-A-ACQ/tasks/four-channel-diagnostic-01/source/rtl/pdm_cic3.v`

只添加对应约束 `project/constraints/sound_servo_burst.xdc`，不要混用独立串口短测XDC。
新空工程打开后，也可在Vivado Tcl Console执行以下一条命令，代替逐个添加以上文件：

```tcl
source C:/Users/hsc/Desktop/fpga_clone/Competition_fpga/project/script/sound_servo_add_sources.tcl
```

预期`SOUND_SERVO_SOURCES_READY: 8 design sources + 1 XDC`；脚本校验目标并拒绝覆盖非空工程，不构建、不下载。
用户建立工程、综合、实现、检查 timing/DRC、生成bit、Hardware Manager下载。
原生输出保存bit、综合/实现日志、timing_summary、DRC及programming日志；本文不宣称这些未做步骤已通过。

## 接线与时钟

U18=50MHz，T19RX/J15TX；水平T15，垂直W16。
四路CLOCK按0–3：V11/Y13/U14/V12；DATA按0–3：Y9/W10/W14/V15。
3.3V逻辑；四路CLOCK为独立输出不得互连；相同信号占用的LCD不得同时驱动。
保留原四麦接线/通道身份。50→96→61.44MHz为官方MMCME2_BASE+BUFG；PDM3.072MHz/CIC64→PCM48kHz。
复位/锁失效使PWM拉低；锁定同步释放后输出H180/V130。V始终130。S/程序结束仅禁用新目标、保持PWM/目标，不是机械刹车。

## 电脑执行

Python3.10+，NumPy和pyserial。仓库根目录执行：

```powershell
python -m pip install -r software/servo_follow/requirements.txt
python software/servo_follow/follow_burst.py --help
```

安装位置固定后，必须自己确认：算法0°对应哪一个机械目标角、同向(+1)还是反向(-1)、物理四麦到算法0/1/2/3的顺序。旧“0°就是180°”已撤回，不默认恢复。
现有B研究包只接受40mm方形候选几何，CLI必须明确确认该候选；这不证明实际阵列几何已测量一致。真实尺寸/顺序不吻合时不能解释为准确声学角度。

执行命令模板（必须将占位值换成自己确认的值）：

```powershell
python software/servo_follow/follow_burst.py --port COM3 --zero <机械零点目标> --polarity <1或-1> --channel-order <0,1,2,3的实际排列> --confirm-candidate-square --cycles 3 --out codex_out/sound-servo-board-new
```

本次不添加170–190°或其他人为机械范围限制，也不再提供`--min/--max`参数。水平允许原驱动完整0–360°输入；超过360°的协议输入拒绝，以免9位截断。源方位仍按有符号方位加安装零点和方向映射；计算出的机械目标超出原驱动0–360°时拒绝，不悄悄回绕或夹到端点。0–360°是原驱动量程，不是新增机械限位。
程序先提示采背景（声源停止），然后每轮提示在已安装安全范围内固定持续声源，按回车。自动抓2048个连续四路样本，约43ms，UART传输约2.14s，电脑计算后自动发一个水平角。
只在三个1024样本/512hop帧均无数值错误、最后一帧活动门打开且DOA有效、目标在驱动量程、真实时间未过期时发送。前两帧用于活动门3帧攻击计数，不能称三次DOA都有效。
默认最多4轮；每轮有用户回车，不能用旧文件回放控制。固定声源等待本轮结束再变位置。Ctrl+C/正常结束发送STOP。

需要自动重复观察时，加 `--auto` 并指定有限轮数（`--cycles` 可选1–12）。仍先按提示采一次安静背景，启动持续声源后再按一次回车，之后程序逐轮自动采新数据、算方向、决定是否下发新目标，不必每轮按回车。每轮使用新的随机nonce，并在上一轮结束后重新ARM；声源可在两轮之间换位置，本轮采集时保持位置稳定。终端显示接受目标时的算法声源角与舵机目标角，`events.jsonl`保存完整数值细节；没有有效结果时不下发新目标。使用25秒测试音频时可先选 `--cycles 6`，播放长度不足则循环播放音频。示例（零点、方向与通道顺序须用实际确认值，输出目录每次换新）：

```powershell
python software/servo_follow/follow_burst.py --port COM3 --zero 180 --polarity 1 --channel-order 0,1,2,3 --confirm-candidate-square --auto --cycles 6 --out codex_out/sound-servo-auto-01
```

此模式仍是每轮2048点的分段采集，串口传输和电脑计算期间没有新的声学样本；不能作为连续48kHz采集或实时跟踪的通过证据。`--auto`省去逐轮回车，未改FPGA bit、算法门槛、TTL或STOP语义。

输出：`background.raw`、`capture_01.raw`等（样本优先、每样本CH0..3、signed24 LE），`events.jsonl`含原始数据SHA256、实际时刻、窗口/nonce、各数值阶段、算法角、被接受目标或拒绝原因。数据不覆盖。另由用户记录实际转向/位置观察；协议ACK不证明机械到位。

## 数据/命令协议

1152008N1，命令16字节：`SC`(2)、op(1)、reserved0(1)、nonceLE32、windowLE32、angleLE16、xor前14字节、LF。
op1ARM(nonzero随机nonce，window重新从0)、2CAP(必须下一window)、3TARGET(单次消费当前window)、4STOP(禁新运动，任意nonce)。
回复24byte头：`SSB1`、type(1capture/2ACK)、status(0OK/1拒绝/2clip)、reservedLE16=0、nonceLE32、windowLE32、samplesLE16(2048或0)、channels4、width3、fsLE32=48000。
接payload（capture24576bytes，ACK无payload），再IEEE CRC32 LE（头+payload）。身份/CRC/clip失败终止；无自动重试。
捕获完成起10秒TTL，超时禁新运动。主机从请求开始计时，更保守。命令部分包1秒超时；格式/范围/过期/忙时非法命令禁用新运动。下一轮明确回车再ARM新nonce。锁失效复位nonce/window，旧命令不匹配不可运动。
捕获RAM冻结直到串口最后字节被接受且发送器已空闲；请求/完成各2FF toggle同步，读地址在50MHz域，数据采集61.44MHz。没有连续传输吞吐保证。

## 当前边界

没有正式IO采样余量/路由STA/真实声学精度证据。麦克风输入2FF和phase9取样复用已有诊断策略。此候选不是主线PS/DMA实现，不改已批准B算法或A采集工程；正式连续闭环仍由团队原任务接入。
